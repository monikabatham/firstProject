// $http.get("https://service.mynowigence.com/service/rest/jsonServices/accountsV3", 
// {headers: {"Authorization": "Basic "+$scope.data.password}})
// .then(function(response) {
// $scope.accounts=[];
// angular.forEach(response.data.accounts, function(acc){
// $scope.accounts.push({"id":acc.id,"name":acc.name});
//  }); 
//$scope.accounts = response.data.accounts;  //[{"id":"1001","name":"System Test"}];
//$scope.repeatCall();
// });